"File descriptions" content plugin for TotalCmd 6.5+
----------------------------------------------------
This content plugin shows file descriptions:

 - for all: descriptions from Descript.ion/Files.bbs;
 - for HTML files: title/meta tags;
 - for text files: file contents;
 - for executables/DLLs: VersionInfo fields.

For Files.bbs descriptions and for text files 2 columns can be shown:
"Short description" (first description line) and "Long description"
(all lines separated by spaces).


Installation
------------
1. Zip archive contains "installation file" for TC, so just open
   archive and TC will install plugin.
2. Goto Options->Custom columns;
   select some view (#N) and add column from FileDiz list.
3. Select custom view:
   Show->Custom columns->#N;
   new column will show file descriptions.


Versions history
----------------
03/06/05: fixed displaying of Files.bbs multi-line comments
15/05/05: shows <META> tag for HTML files (see FileDiz.ini)
15/04/05: added feature: you may specify text replace strings in FileDiz.ini
18/03/05: fixed reading Descript.ion if filename has spaces
15/03/05: added source code
07/11/04: added subfileds "Private build", "Special build"
06/11/04: added field "Version info" with all standard subfields;
          useful for searching executables by version
05/11/04: shows VersionInfo fields for executables
05/11/04: shows HTML/Text descriptions (configured in FileDiz.ini)
28/10/04: shows also descriptions from Files.bbs (in OEM code)
25/10/04: initial version

(c) 2005 Alexey Torgashin <atorg@yandex.ru>
http://atlsoft.front.ru
http://totalcmd.net/plugring/FileDiz.html
